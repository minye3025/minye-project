from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://qoxzkngo:FkXK8cpv54MATdrq4jhpvsSlvqK43SkO@localhost/mydatabase'

    db.init_app(app)
    migrate.init_app(app, db)

    from flask_app.routes import (main_route, course_route)
    app.register_blueprint(main_route.bp)
    app.register_blueprint(course_route.bp)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)






"""
배포 관련 내용
def create_app():
    app = Flask(__name__)

    # 배포 대비 구성환경 및 디버그 모드 설정 인 듯
    # https://flask.palletsprojects.com/en/2.0.x/config/ 참고하기
    if app.config["ENV"] == 'production':
        app.config.from_object('config.ProductionConfig')
    else:
        app.config.from_object('config.DevelopmentConfig')

    if config is not None:
        app.config.update(config)

    
    db.init_app(app)
    migrate.init_app(app, db)


    from flask_app.routes import (main_route, user_route)
    app.register_blueprint(main_route.bp)
    app.register_blueprint(user_route.bp, url_prefix='/api')

    return app
"""




