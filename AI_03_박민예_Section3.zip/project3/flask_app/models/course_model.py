from flask_app import db

class Course(db.Model):
    __tablename__ = 'course'

    코스명 = db.Column(db.TEXT, primary_key=True)
    코스구분 = db.Column(db.TEXT)
    출발점 = db.Column(db.TEXT)
    도착점 = db.Column(db.TEXT)
    소개 = db.Column(db.TEXT)

    def __repr__(self):
        return f"Course {self.코스명}, {self.코스구분}, {self.출발점}, {self.도착점}, {self.소개}"


