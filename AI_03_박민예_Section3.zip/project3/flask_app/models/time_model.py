from flask_app import db

class Time(db.Model):
    __tablename__ = 'time'

    코스명 = db.Column(db.TEXT, primary_key=True)
    소요시간 = db.Column(db.Integer)
    소요분 = db.Column(db.Integer)
    couses = db.relationship('Course', backref='time', lazy=True)

    def __repr__(self):
        return f"{self.코스명}, {self.소요시간}, {self.소요분}"