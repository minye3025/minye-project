from flask import Blueprint, request, redirect, url_for, Response, render_template
from flask_app.models import course_model, time_model

bp = Blueprint('course', __name__, url_prefix='/course')

@bp.route('/course', methods=['POST'])
def course():
    return render_template('course.html')