from flask import Blueprint, render_template, request
from flask_app import db
from flask_app.models import course_model, time_model

bp = Blueprint('main', __name__, url_prefix='/')

@bp.route('/')
def index():
    return render_template('index.html')

